-- =========================================================
-- Zakerly — Supabase schema
-- Run this once in the Supabase SQL editor (Project > SQL Editor > New query)
-- =========================================================

-- =========================================================
-- 1. profiles — mirrors auth.users, one row per signed-up user
-- =========================================================
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  created_at timestamptz not null default now()
);

-- Whenever someone signs up (email or Google), Supabase adds a row to
-- auth.users automatically. This trigger copies that into our own
-- "profiles" table so we have an app-level place to store user data.
create function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email)
  values (new.id, new.email);
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- =========================================================
-- 2. generations — cache of AI outputs
-- =========================================================
create table public.generations (
  id uuid primary key default gen_random_uuid(),
  cache_key text not null unique, -- sha256(text + subject + grade + action)
  action text not null check (action in ('summary', 'questions', 'flashcards')),
  subject text not null check (subject in ('arabic', 'english', 'math', 'science', 'social_studies')),
  grade text not null check (grade in (
    'primary1','primary2','primary3','primary4','primary5','primary6',
    'prep1','prep2','prep3',
    'secondary1','secondary2','secondary3'
  )),
  result jsonb not null,
  created_at timestamptz not null default now()
);

create index idx_generations_cache_key on public.generations (cache_key);

-- =========================================================
-- 3. usage_counters — daily rate limit per user
-- =========================================================
create table public.usage_counters (
  user_id uuid not null references auth.users(id) on delete cascade,
  usage_date date not null default current_date,
  count int not null default 0,
  primary key (user_id, usage_date)
);

-- =========================================================
-- Row Level Security
-- =========================================================
alter table public.profiles enable row level security;
alter table public.generations enable row level security;
alter table public.usage_counters enable row level security;

create policy "profiles_select_own" on public.profiles
  for select using (auth.uid() = id);
create policy "profiles_update_own" on public.profiles
  for update using (auth.uid() = id);

-- generations has no personal data in it (just lesson text + AI output),
-- so any logged-in user can read the cache. Only the server (using the
-- service role key, which bypasses RLS) is allowed to write to it.
create policy "generations_select_authenticated" on public.generations
  for select using (auth.role() = 'authenticated');

-- usage_counters: a user can see their own count, but cannot write to it
-- directly from the browser — only our server-side API route (using the
-- service role key) increments it. This stops a student from editing
-- their own count in devtools to bypass the daily limit.
create policy "usage_counters_select_own" on public.usage_counters
  for select using (auth.uid() = user_id);
