'use client';

import { useRef, useState } from 'react';
import type { Action, Grade, Subject } from '@/types/generation';

const SUBJECTS: { value: Subject; label: string }[] = [
  { value: 'arabic', label: 'اللغة العربية' },
  { value: 'english', label: 'اللغة الإنجليزية' },
  { value: 'math', label: 'الرياضيات' },
  { value: 'science', label: 'العلوم' },
  { value: 'social_studies', label: 'الدراسات الاجتماعية' },
];

const GRADES: { value: Grade; label: string }[] = [
  { value: 'primary1', label: 'الأول الابتدائي' },
  { value: 'primary2', label: 'الثاني الابتدائي' },
  { value: 'primary3', label: 'الثالث الابتدائي' },
  { value: 'primary4', label: 'الرابع الابتدائي' },
  { value: 'primary5', label: 'الخامس الابتدائي' },
  { value: 'primary6', label: 'السادس الابتدائي' },
  { value: 'prep1', label: 'الأول الإعدادي' },
  { value: 'prep2', label: 'الثاني الإعدادي' },
  { value: 'prep3', label: 'الثالث الإعدادي' },
  { value: 'secondary1', label: 'الأول الثانوي' },
  { value: 'secondary2', label: 'الثاني الثانوي' },
  { value: 'secondary3', label: 'الثالث الثانوي' },
];

const MAX_LENGTH = 8000;

function toArabicDigits(n: number): string {
  const map = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  return String(n).replace(/[0-9]/g, (d) => map[Number(d)]);
}

interface Props {
  text: string;
  setText: (v: string) => void;
  subject: Subject | null;
  setSubject: (v: Subject) => void;
  grade: Grade | null;
  setGrade: (v: Grade) => void;
  onGenerate: (action: Action) => void;
  isLoading: boolean;
}

export function StudyForm({
  text,
  setText,
  subject,
  setSubject,
  grade,
  setGrade,
  onGenerate,
  isLoading,
}: Props) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [ocrStatus, setOcrStatus] = useState<string | null>(null);
  const [ocrLoading, setOcrLoading] = useState(false);

  const ready = text.trim().length > 0 && subject && grade && !isLoading;

  // Shrinks the photo before upload (phone photos can be 4-5MB) using a
  // canvas — this is much faster to upload and Gemini reads it just as
  // well as the full-size original.
  function resizeImageToBase64(file: File, maxDim = 1600): Promise<{ base64: string; mimeType: string }> {
    return new Promise((resolve, reject) => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.onload = () => {
        let { width, height } = img;
        if (width > maxDim || height > maxDim) {
          const scale = maxDim / Math.max(width, height);
          width = Math.round(width * scale);
          height = Math.round(height * scale);
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        canvas.getContext('2d')!.drawImage(img, 0, 0, width, height);
        URL.revokeObjectURL(url);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
        resolve({ base64: dataUrl.split(',')[1], mimeType: 'image/jpeg' });
      };
      img.onerror = reject;
      img.src = url;
    });
  }

  async function handleFileSelected(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    setOcrLoading(true);
    setOcrStatus('جاري قراءة النص من الصورة...');

    try {
      const { base64, mimeType } = await resizeImageToBase64(file);

      const res = await fetch('/api/ocr', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64: base64, mimeType }),
      });
      const data = await res.json();

      if (!res.ok) {
        setOcrStatus(`⚠️ ${data.message}`);
      } else {
        setText(data.text);
        setOcrStatus('✅ تم استخراج النص بنجاح — راجعه وعدّله لو محتاج');
      }
    } catch {
      setOcrStatus('⚠️ حصل خطأ في قراءة الصورة، حاول تاني');
    } finally {
      setOcrLoading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
      setTimeout(() => setOcrStatus(null), 4000);
    }
  }

  return (
    <div>
      {/* ---- Photo-of-the-book OCR ---- */}
      <div className="mb-3">
        <button
          type="button"
          disabled={ocrLoading}
          onClick={() => fileInputRef.current?.click()}
          className="w-full border-[1.5px] border-dashed border-gold text-yellow-700 rounded-2xl py-3 text-sm font-bold disabled:opacity-60"
        >
          📷 صوّر صفحة من الكتاب بدل الكتابة
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          hidden
          onChange={handleFileSelected}
        />
        {ocrStatus && <p className="text-xs text-gray-500 mt-2">{ocrStatus}</p>}
      </div>

      {/* ---- Lesson text ---- */}
      <label className="block text-sm font-bold text-navy mb-2">الصق نص الدرس هنا</label>
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value.slice(0, MAX_LENGTH))}
        maxLength={MAX_LENGTH}
        placeholder="مثال: الخلية هي الوحدة الأساسية لبناء جسم الكائن الحي..."
        className="w-full min-h-[140px] border-[1.5px] border-gray-200 rounded-2xl p-3.5 text-[15px] leading-7 focus:outline-none focus:border-gold"
      />
      <div className="text-left text-xs text-gray-400 mt-1.5">
        {toArabicDigits(text.length)} / {toArabicDigits(MAX_LENGTH)} حرف
      </div>

      {/* ---- Subject ---- */}
      <div className="mt-5">
        <label className="block text-sm font-bold text-navy mb-2">المادة</label>
        <div className="flex flex-wrap gap-2">
          {SUBJECTS.map((s) => (
            <button
              key={s.value}
              type="button"
              onClick={() => setSubject(s.value)}
              className={`border-[1.5px] rounded-full px-4 py-2 text-sm font-bold ${
                subject === s.value
                  ? 'bg-navy border-navy text-white'
                  : 'bg-white border-gray-200 text-navy hover:border-gold'
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {/* ---- Grade ---- */}
      <div className="mt-5">
        <label className="block text-sm font-bold text-navy mb-2">الصف الدراسي</label>
        <div className="flex flex-wrap gap-2">
          {GRADES.map((g) => (
            <button
              key={g.value}
              type="button"
              onClick={() => setGrade(g.value)}
              className={`border-[1.5px] rounded-full px-4 py-2 text-sm font-bold ${
                grade === g.value
                  ? 'bg-navy border-navy text-white'
                  : 'bg-white border-gray-200 text-navy hover:border-gold'
              }`}
            >
              {g.label}
            </button>
          ))}
        </div>
      </div>

      {/* ---- Actions ---- */}
      <div className="flex flex-col gap-2.5 mt-6">
        <button
          type="button"
          disabled={!ready}
          onClick={() => onGenerate('summary')}
          className="w-full py-4 rounded-2xl bg-navy text-white font-extrabold disabled:opacity-40"
        >
          📄 ملخص
        </button>
        <button
          type="button"
          disabled={!ready}
          onClick={() => onGenerate('questions')}
          className="w-full py-4 rounded-2xl bg-gold text-navy font-extrabold disabled:opacity-40"
        >
          ❓ أسئلة (١٠ اختيار من متعدد)
        </button>
        <button
          type="button"
          disabled={!ready}
          onClick={() => onGenerate('flashcards')}
          className="w-full py-4 rounded-2xl bg-teal text-white font-extrabold disabled:opacity-40"
        >
          🗂️ فلاش كاردز
        </button>
      </div>
    </div>
  );
}
