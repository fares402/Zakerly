export function ErrorBanner({ message }: { message: string }) {
  return (
    <div className="bg-red-50 border-[1.5px] border-red-400 text-red-600 px-4 py-3 rounded-2xl text-sm font-semibold text-center">
      {message}
    </div>
  );
}
