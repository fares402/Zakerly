'use client';

import { useState } from 'react';
import type { QuestionItem } from '@/types/generation';

// Arabic-Indic digit conversion, so question numbers show as ١، ٢، ٣...
function toArabicDigits(n: number): string {
  const map = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  return String(n).replace(/[0-9]/g, (d) => map[Number(d)]);
}

function QuestionCard({ item, index }: { item: QuestionItem; index: number }) {
  // Tracks which option (if any) the student has clicked for THIS question.
  const [selected, setSelected] = useState<number | null>(null);

  return (
    <div className="mb-6 last:mb-0">
      <p className="font-bold text-navy mb-3">
        {toArabicDigits(index + 1)}. {item.question}
      </p>
      <div className="flex flex-col gap-2">
        {item.options.map((opt, i) => {
          const isAnswered = selected !== null;
          const isCorrect = i === item.correctIndex;
          const isPickedWrong = isAnswered && i === selected && !isCorrect;

          let classes =
            'border-[1.5px] rounded-xl px-4 py-3 text-sm text-right transition-colors ';
          if (!isAnswered) {
            classes += 'border-gray-200 hover:border-gold cursor-pointer';
          } else if (isCorrect) {
            classes += 'bg-green-50 border-teal text-teal-700 font-bold cursor-default';
          } else if (isPickedWrong) {
            classes += 'bg-red-50 border-red-400 text-red-600 font-bold cursor-default';
          } else {
            classes += 'border-gray-200 opacity-60 cursor-default';
          }

          return (
            <button
              key={i}
              type="button"
              disabled={isAnswered}
              onClick={() => setSelected(i)}
              className={classes}
            >
              {opt}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export function QuestionsResult({ questions }: { questions: QuestionItem[] }) {
  return (
    <div className="bg-white border-[1.5px] border-gray-200 rounded-2xl p-5">
      <p className="text-xs font-bold text-gold mb-4">الأسئلة</p>
      {questions.map((q, i) => (
        <QuestionCard key={i} item={q} index={i} />
      ))}
    </div>
  );
}
