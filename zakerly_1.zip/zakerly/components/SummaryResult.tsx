export function SummaryResult({ summary }: { summary: string }) {
  return (
    <div className="bg-white border-[1.5px] border-gray-200 rounded-2xl p-5">
      <p className="text-xs font-bold text-gold mb-3">الملخص</p>
      <p className="text-[15.5px] leading-8 whitespace-pre-line">{summary}</p>
    </div>
  );
}
