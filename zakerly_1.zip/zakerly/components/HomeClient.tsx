'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { StudyForm } from '@/components/StudyForm';
import { SummaryResult } from '@/components/SummaryResult';
import { QuestionsResult } from '@/components/QuestionsResult';
import { FlashcardsResult } from '@/components/FlashcardsResult';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { ErrorBanner } from '@/components/ErrorBanner';
import type { Action, Grade, GenerateResult, Subject } from '@/types/generation';

const LOADING_MESSAGES: Record<Action, string> = {
  summary: 'جاري تلخيص الدرس...',
  questions: 'جاري تجهيز الأسئلة...',
  flashcards: 'جاري إعداد الفلاش كاردز...',
};

// Typing this exact phrase into the lesson textarea, PLUS picking
// "الأول الإعدادي" + "الرياضيات", PLUS clicking "فلاش كاردز" — that
// specific combination navigates to the admin panel instead of
// generating flashcards. Requiring all four makes it very unlikely
// anyone stumbles onto it by accident.
//
// This is just a navigation shortcut, NOT a security bypass — /admin
// still fully requires your admin email (checked server-side in
// middleware.ts) and the daily password (AdminGate.tsx) before it shows
// anything. Someone finding this combo gains nothing without both of
// those too.
const ADMIN_TRIGGER = 'fares14102013';

export function HomeClient() {
  const router = useRouter();
  const [text, setText] = useState('');
  const [subject, setSubject] = useState<Subject | null>(null);
  const [grade, setGrade] = useState<Grade | null>(null);

  const [loadingAction, setLoadingAction] = useState<Action | null>(null);
  const [result, setResult] = useState<GenerateResult | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  async function handleGenerate(action: Action) {
    if (!subject || !grade) return;

    const isAdminCombo =
      action === 'flashcards' &&
      text.trim() === ADMIN_TRIGGER &&
      grade === 'prep1' &&
      subject === 'math';

    if (isAdminCombo) {
      router.push('/admin');
      return;
    }

    setLoadingAction(action);
    setResult(null);
    setErrorMessage(null);

    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, subject, grade, action }),
      });
      const data = await res.json();

      if (!res.ok) {
        setErrorMessage(data.message ?? 'حصل خطأ، حاول تاني.');
      } else {
        setResult(data.result);
      }
    } catch {
      setErrorMessage('حصل خطأ في الاتصال، تأكد من الإنترنت وحاول تاني.');
    } finally {
      setLoadingAction(null);
    }
  }

  return (
    <>
      <StudyForm
        text={text}
        setText={setText}
        subject={subject}
        setSubject={setSubject}
        grade={grade}
        setGrade={setGrade}
        onGenerate={handleGenerate}
        isLoading={loadingAction !== null}
      />

      <div className="mt-7">
        {loadingAction && <LoadingSpinner message={LOADING_MESSAGES[loadingAction]} />}
        {!loadingAction && errorMessage && <ErrorBanner message={errorMessage} />}
        {!loadingAction && result && 'summary' in result && (
          <SummaryResult summary={result.summary} />
        )}
        {!loadingAction && result && 'questions' in result && (
          <QuestionsResult questions={result.questions} />
        )}
        {!loadingAction && result && 'flashcards' in result && (
          <FlashcardsResult flashcards={result.flashcards} />
        )}
      </div>
    </>
  );
}
