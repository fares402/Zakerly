'use client';

import { useState } from 'react';
import type { FlashcardItem } from '@/types/generation';

function Flashcard({ card }: { card: FlashcardItem }) {
  const [flipped, setFlipped] = useState(false);

  return (
    <div
      className={`flash-card h-32 cursor-pointer ${flipped ? 'flipped' : ''}`}
      onClick={() => setFlipped(!flipped)}
    >
      <div className="flash-inner">
        <div className="flash-face bg-navy text-white flex items-center justify-center text-center p-4 font-bold">
          {card.front}
        </div>
        <div className="flash-face flash-back bg-teal text-white flex items-center justify-center text-center p-4">
          {card.back}
        </div>
      </div>
    </div>
  );
}

export function FlashcardsResult({ flashcards }: { flashcards: FlashcardItem[] }) {
  return (
    <div className="bg-white border-[1.5px] border-gray-200 rounded-2xl p-5">
      <p className="text-xs font-bold text-gold mb-4">فلاش كاردز — اضغط على الكارت لقلبه</p>
      <div className="flex flex-col gap-3">
        {flashcards.map((card, i) => (
          <Flashcard key={i} card={card} />
        ))}
      </div>
    </div>
  );
}
