'use client';

// A lightweight extra layer for the admin panel: even if someone is
// using your already-logged-in phone/browser and taps the admin link,
// they still need to type today's date (day/month, e.g. "3/9") to see
// the table.
//
// IMPORTANT — be clear-eyed about what this is and isn't:
// - The REAL security is the email check in middleware.ts + admin/page.tsx
//   server-side, which nobody can bypass no matter what they type here.
// - THIS password is guessable by anyone who knows the pattern (it's
//   just today's date). It's a casual speed-bump, not real protection —
//   fine for "little brother opens my phone", not fine as your only
//   line of defense for anything sensitive.

import { useState } from 'react';

function getTodayPassword(): string {
  const now = new Date();
  return `${now.getDate()}/${now.getMonth() + 1}`; // e.g. "3/9", no leading zeros
}

export function AdminGate({ children }: { children: React.ReactNode }) {
  const [input, setInput] = useState('');
  const [unlocked, setUnlocked] = useState(false);
  const [error, setError] = useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (input.trim() === getTodayPassword()) {
      setUnlocked(true);
      setError(false);
    } else {
      setError(true);
    }
  }

  if (unlocked) return <>{children}</>;

  return (
    <div className="max-w-sm mx-auto mt-20 bg-white border border-gray-200 rounded-2xl p-6" dir="rtl">
      <p className="font-bold text-navy mb-1">كلمة السر</p>
      <p className="text-xs text-gray-500 mb-4">اكتب تاريخ النهاردة (يوم/شهر) — مثال: 3/9</p>
      <form onSubmit={handleSubmit} className="flex flex-col gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="border border-gray-200 rounded-xl px-3 py-2 text-sm text-center"
          autoFocus
        />
        {error && <p className="text-red-600 text-xs text-center">غلط، جرب تاني</p>}
        <button type="submit" className="bg-navy text-white rounded-xl py-2 text-sm font-bold mt-1">
          دخول
        </button>
      </form>
    </div>
  );
}
