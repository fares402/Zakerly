'use client';

// Login page: lets a student sign in with email+password or Google.
//
// Security notes (see chat explanation):
// - The password input uses type="password" so it's masked on screen.
// - We never console.log() the password or store it anywhere beyond
//   the local component state needed to submit the form.
// - The actual network request is handled by the Supabase SDK over
//   HTTPS, so the password is encrypted in transit.

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

export default function LoginPage() {
  const router = useRouter();
  const supabase = createClient();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  async function handleEmailSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setErrorMessage('');

    const { error } =
      mode === 'login'
        ? await supabase.auth.signInWithPassword({ email, password })
        : await supabase.auth.signUp({ email, password });

    setLoading(false);

    if (error) {
      // Friendly Arabic message instead of Supabase's raw English error.
      setErrorMessage('البريد الإلكتروني أو كلمة المرور غير صحيحة، حاول مرة أخرى.');
      return;
    }

    router.push('/');
    router.refresh();
  }

  async function handleGoogleLogin() {
    await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: `${window.location.origin}/auth/callback` },
    });
  }

  return (
    <div className="min-h-screen bg-navy flex items-center justify-center px-5">
      <div className="w-full max-w-sm bg-paper rounded-3xl p-6 shadow-xl">
        <h1 className="text-2xl font-black text-navy text-center mb-1">ذاكرلي</h1>
        <p className="text-sm text-gray-500 text-center mb-6">
          {mode === 'login' ? 'سجّل دخولك عشان تبدأ المذاكرة' : 'أنشئ حساب جديد'}
        </p>

        <form onSubmit={handleEmailSubmit} className="flex flex-col gap-3">
          <input
            type="email"
            required
            placeholder="البريد الإلكتروني"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="border border-gray-200 rounded-2xl px-4 py-3 text-sm focus:outline-none focus:border-gold"
          />
          <input
            type="password"
            required
            minLength={6}
            placeholder="كلمة المرور"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            // autoComplete lets the browser's own password manager offer
            // to save it securely — that's a better place for it to live
            // than anywhere in our app's code.
            autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
            className="border border-gray-200 rounded-2xl px-4 py-3 text-sm focus:outline-none focus:border-gold"
          />

          {errorMessage && (
            <p className="text-red-600 text-sm text-center">{errorMessage}</p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="bg-navy text-white font-bold rounded-2xl py-3 mt-1 disabled:opacity-50"
          >
            {loading ? 'جاري الدخول...' : mode === 'login' ? 'تسجيل الدخول' : 'إنشاء حساب'}
          </button>
        </form>

        <button
          onClick={() => setMode(mode === 'login' ? 'signup' : 'login')}
          className="text-sm text-gray-500 text-center w-full mt-3"
        >
          {mode === 'login' ? 'مفيش حساب؟ أنشئ واحد' : 'عندك حساب؟ سجّل دخولك'}
        </button>

        <div className="flex items-center gap-3 my-5">
          <div className="h-px bg-gray-200 flex-1" />
          <span className="text-xs text-gray-400">أو</span>
          <div className="h-px bg-gray-200 flex-1" />
        </div>

        <button
          onClick={handleGoogleLogin}
          className="w-full border border-gray-200 rounded-2xl py-3 text-sm font-bold flex items-center justify-center gap-2"
        >
          تسجيل الدخول بجوجل
        </button>
      </div>
    </div>
  );
}
