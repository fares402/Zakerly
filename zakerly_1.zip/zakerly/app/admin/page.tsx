// A simple private page only you can see (protected by middleware.ts,
// which checks the logged-in email against ADMIN_EMAIL). Shows every
// student who has ever signed up, and how many generations they've
// used today.
//
// NOTE: this only lists people who created an ACCOUNT (email/password
// signup or Google login) — since the middleware requires login before
// reaching the main page, someone who just "visits the site" without
// signing up never gets a row in `profiles` and won't appear here.

import { createServerClient, createAdminClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';
import { AdminGate } from '@/components/AdminGate';

export default async function AdminPage() {
  const supabase = createServerClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  // Defense in depth: even though middleware already blocks non-admins
  // from reaching this page, we check again here directly.
  if (!user || user.email !== process.env.ADMIN_EMAIL) {
    redirect('/');
  }

  const admin = createAdminClient();
  const today = new Date().toISOString().slice(0, 10);

  const { data: profiles } = await admin
    .from('profiles')
    .select('id, email, created_at')
    .order('created_at', { ascending: false });

  const { data: usageRows } = await admin
    .from('usage_counters')
    .select('user_id, count')
    .eq('usage_date', today);

  const usageByUser = new Map((usageRows ?? []).map((r) => [r.user_id, r.count]));

  return (
    <div dir="rtl" className="min-h-screen bg-paper p-6">
      <AdminGate>
        <h1 className="text-xl font-black text-navy mb-1">المستخدمين المسجلين</h1>
        <p className="text-sm text-gray-500 mb-6">
          {(profiles ?? []).length} مستخدم مسجل — الصفحة دي ليك انت بس
        </p>

        <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
          <table className="w-full text-sm text-right">
            <thead className="bg-gray-50 text-gray-500">
              <tr>
                <th className="p-3">البريد الإلكتروني</th>
                <th className="p-3">تاريخ التسجيل</th>
                <th className="p-3">محاولات اليوم</th>
              </tr>
            </thead>
            <tbody>
              {(profiles ?? []).map((p) => (
                <tr key={p.id} className="border-t border-gray-100">
                  <td className="p-3 font-medium">{p.email}</td>
                  <td className="p-3 text-gray-500">
                    {new Date(p.created_at).toLocaleDateString('ar-EG')}
                  </td>
                  <td className="p-3">{usageByUser.get(p.id) ?? 0} / 10</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </AdminGate>
    </div>
  );
}
