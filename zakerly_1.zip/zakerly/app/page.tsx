// The main page shell. All the interactive parts (the form, the
// buttons, calling the API) live in HomeClient.tsx, which is a client
// component. The admin panel is no longer linked from here — see
// HomeClient.tsx for the hidden text-trigger that opens it.

import { HomeClient } from '@/components/HomeClient';

export default function HomePage() {
  return (
    <div className="max-w-[560px] mx-auto min-h-screen flex flex-col">
      <header className="text-center text-white px-5 pt-7 pb-10">
        <h1 className="text-3xl font-black">ذاكرلي</h1>
        <p className="text-sm text-gray-300 mt-1">مساعدك في المذاكرة بالذكاء الاصطناعي</p>
      </header>

      <main className="bg-paper flex-1 rounded-t-[28px] px-5 pt-7 pb-14 shadow-xl">
        <HomeClient />
      </main>
    </div>
  );
}
