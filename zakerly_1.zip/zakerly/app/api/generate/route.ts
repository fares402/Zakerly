// This is the one route that talks to Gemini. Everything else in the
// app (the UI, the buttons) just calls this endpoint.
//
// ASSUMPTION (flagged in the spec, section on caching vs. variety):
// "summary" results ARE cached — pasting the same lesson text twice
// returns the same summary instantly, without calling Gemini again.
// "questions" and "flashcards" are NEVER cached — every click calls
// Gemini fresh, so the student gets a different set each time (this is
// what you asked for). This means only "summary" saves you money via
// the cache; the other two always cost a real Gemini call.

import { NextResponse } from 'next/server';
import { createServerClient, createAdminClient } from '@/lib/supabase/server';
import { generateText, extractJSON } from '@/lib/gemini';
import { buildPrompt } from '@/lib/prompts';
import { makeCacheKey } from '@/lib/hash';
import { checkAndIncrementUsage } from '@/lib/rateLimit';
import type { GenerateRequestBody, GenerateResult } from '@/types/generation';

const VALID_SUBJECTS = ['arabic', 'english', 'math', 'science', 'social_studies'];
const VALID_GRADES = [
  'primary1', 'primary2', 'primary3', 'primary4', 'primary5', 'primary6',
  'prep1', 'prep2', 'prep3',
  'secondary1', 'secondary2', 'secondary3',
];
const VALID_ACTIONS = ['summary', 'questions', 'flashcards'];
const MAX_TEXT_LENGTH = 8000;

export async function POST(request: Request) {
  // ---- 1. Check the user is logged in ----
  const supabase = createServerClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json(
      { error: 'unauthorized', message: 'من فضلك سجّل دخولك الأول.' },
      { status: 401 }
    );
  }

  // ---- 2. Validate the input ----
  const body: GenerateRequestBody = await request.json();
  const { text, subject, grade, action } = body;

  if (
    !text ||
    typeof text !== 'string' ||
    text.trim().length === 0 ||
    text.length > MAX_TEXT_LENGTH ||
    !VALID_SUBJECTS.includes(subject) ||
    !VALID_GRADES.includes(grade) ||
    !VALID_ACTIONS.includes(action)
  ) {
    return NextResponse.json(
      { error: 'invalid_input', message: 'من فضلك تأكد من النص والمادة والصف قبل ما تكمل.' },
      { status: 400 }
    );
  }

  const admin = createAdminClient();

  // ---- 3. Cache lookup (summary only — see note at top of file) ----
  const cacheKey = makeCacheKey({ text, subject, grade, action });

  if (action === 'summary') {
    const { data: cached } = await admin
      .from('generations')
      .select('result')
      .eq('cache_key', cacheKey)
      .maybeSingle();

    if (cached) {
      return NextResponse.json({ result: cached.result, cached: true });
    }
  }

  // ---- 4. Rate limit check (cache hits above never reach this point) ----
  const usage = await checkAndIncrementUsage(user.id, user.email);
  if (!usage.allowed) {
    return NextResponse.json(
      {
        error: 'rate_limit',
        message: 'وصلت للحد الأقصى (١٠ محاولات) اليوم. جرب تاني بكرة!',
      },
      { status: 429 }
    );
  }

  // ---- 5. Call Gemini ----
  const prompt = buildPrompt(action, text, subject, grade);

  try {
    const rawText = await generateText(prompt);
    let result: GenerateResult;

    if (action === 'summary') {
      result = { summary: rawText.trim() };
    } else if (action === 'questions') {
      const parsed = extractJSON<{ questions: unknown }>(rawText);
      result = { questions: parsed.questions as any };
    } else {
      const parsed = extractJSON<{ flashcards: unknown }>(rawText);
      result = { flashcards: parsed.flashcards as any };
    }

    // ---- 6. Save to cache (summary only) ----
    if (action === 'summary') {
      await admin.from('generations').insert({
        cache_key: cacheKey,
        action,
        subject,
        grade,
        result,
      });
    }

    return NextResponse.json({ result, cached: false });
  } catch (err) {
    console.error('Gemini generation failed:', err);
    return NextResponse.json(
      {
        error: 'gemini_unavailable',
        message: 'حصل خطأ أثناء التوليد، من فضلك حاول مرة أخرى بعد شوية.',
      },
      { status: 503 }
    );
  }
}
