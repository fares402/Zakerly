import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'ذاكرلي',
  description: 'مساعدك في المذاكرة بالذكاء الاصطناعي',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="font-sans bg-navy">{children}</body>
    </html>
  );
}
