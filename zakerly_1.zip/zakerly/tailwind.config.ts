import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        // Tajawal is a free Google Font that supports Arabic well and
        // looks clean on both mobile and desktop.
        sans: ['Tajawal', 'sans-serif'],
      },
      colors: {
        // Matching the palette from the approved preview
        navy: '#14213D',
        gold: '#E3A008',
        teal: '#2A9D8F',
        paper: '#FFFDF8',
      },
    },
  },
  plugins: [],
};
export default config;
