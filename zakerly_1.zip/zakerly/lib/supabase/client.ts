// This file creates a Supabase client for use IN THE BROWSER.
// It uses the "anon" key, which is safe to expose publicly — Supabase's
// Row Level Security (RLS) rules (see supabase/schema.sql) control what
// this client is actually allowed to read or write.

import { createBrowserClient } from '@supabase/ssr';

export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
