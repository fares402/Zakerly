// This file creates TWO different Supabase clients for server-side code
// (API routes, Server Components). They serve different purposes:
//
// 1. createServerClient() — reads the logged-in user's session from
//    their browser cookies. Use this to find out WHO is making the
//    request. It still respects Row Level Security (RLS).
//
// 2. createAdminClient() — uses the SECRET service role key, which
//    bypasses RLS entirely. Use this ONLY for writes that the app
//    itself needs to do on the user's behalf (like incrementing their
//    usage counter, or saving to the shared cache) — never expose this
//    client or its key to the browser.

import { createServerClient as createSupabaseServerClient } from '@supabase/ssr';
import { createClient as createSupabaseAdminClient } from '@supabase/supabase-js';
import { cookies } from 'next/headers';

export function createServerClient() {
  const cookieStore = cookies();

  return createSupabaseServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return cookieStore.get(name)?.value;
        },
        // API routes in Next.js can't always set cookies (only Server
        // Actions and Route Handlers with special setup can), so we
        // provide no-op set/remove here. This client is only used to
        // READ the session in our API routes, not to refresh it.
        set() {},
        remove() {},
      },
    }
  );
}

export function createAdminClient() {
  return createSupabaseAdminClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );
}
