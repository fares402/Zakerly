// Wraps the @google/generative-ai SDK so the rest of the app never has
// to think about retry logic or which model name to use.

import { GoogleGenerativeAI } from '@google/generative-ai';

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);
const model = genAI.getGenerativeModel({ model: 'gemini-2.5-flash' });

// Backoff schedule from the spec: 1s, 2s, 4s, 8s (4 attempts total).
const BACKOFF_MS = [1000, 2000, 4000, 8000];

/**
 * Sends a text prompt to Gemini and returns the raw text response.
 * Retries automatically if Gemini responds with a 429 (rate limited).
 */
export async function generateText(prompt: string): Promise<string> {
  let lastError: unknown;

  for (let attempt = 0; attempt <= BACKOFF_MS.length; attempt++) {
    try {
      const result = await model.generateContent(prompt);
      return result.response.text();
    } catch (err: any) {
      lastError = err;
      const is429 = err?.status === 429 || err?.message?.includes('429');
      const isLastAttempt = attempt === BACKOFF_MS.length;

      if (!is429 || isLastAttempt) {
        throw err;
      }
      // Wait, then try again.
      await sleep(BACKOFF_MS[attempt]);
    }
  }

  throw lastError;
}

/**
 * Sends an image + instruction prompt to Gemini (used for the "photo of
 * the book page" OCR feature) and returns the raw text response.
 * Same retry behavior as generateText().
 */
export async function generateFromImage(
  base64Image: string,
  mimeType: string,
  prompt: string
): Promise<string> {
  let lastError: unknown;

  for (let attempt = 0; attempt <= BACKOFF_MS.length; attempt++) {
    try {
      const result = await model.generateContent([
        { inlineData: { data: base64Image, mimeType } },
        prompt,
      ]);
      return result.response.text();
    } catch (err: any) {
      lastError = err;
      const is429 = err?.status === 429 || err?.message?.includes('429');
      const isLastAttempt = attempt === BACKOFF_MS.length;

      if (!is429 || isLastAttempt) {
        throw err;
      }
      await sleep(BACKOFF_MS[attempt]);
    }
  }

  throw lastError;
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** Strips ```json fences (if Gemini adds them anyway) and parses JSON. */
export function extractJSON<T = any>(rawText: string): T {
  const cleaned = rawText.replace(/```json/g, '').replace(/```/g, '').trim();
  return JSON.parse(cleaned);
}
