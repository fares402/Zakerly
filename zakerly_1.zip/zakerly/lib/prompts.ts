// All the text we send to Gemini lives here, in one place, so it's easy
// to tweak the wording without hunting through the API route code.

const SUBJECT_LABELS: Record<string, string> = {
  arabic: 'اللغة العربية',
  english: 'اللغة الإنجليزية',
  math: 'الرياضيات',
  science: 'العلوم',
  social_studies: 'الدراسات الاجتماعية',
};

const GRADE_LABELS: Record<string, string> = {
  primary1: 'الأول الابتدائي',
  primary2: 'الثاني الابتدائي',
  primary3: 'الثالث الابتدائي',
  primary4: 'الرابع الابتدائي',
  primary5: 'الخامس الابتدائي',
  primary6: 'السادس الابتدائي',
  prep1: 'الأول الإعدادي',
  prep2: 'الثاني الإعدادي',
  prep3: 'الثالث الإعدادي',
  secondary1: 'الأول الثانوي',
  secondary2: 'الثاني الثانوي',
  secondary3: 'الثالث الثانوي',
};

export function buildPrompt(
  action: 'summary' | 'questions' | 'flashcards',
  text: string,
  subject: string,
  grade: string
): string {
  const subjectLabel = SUBJECT_LABELS[subject] ?? subject;
  const gradeLabel = GRADE_LABELS[grade] ?? grade;
  const context = `هذه فقرة درس لطالب في الصف "${gradeLabel}" في مادة "${subjectLabel}":\n\n"""${text}"""\n\n`;

  if (action === 'summary') {
    return (
      context +
      'اكتب ملخصًا واضحًا ومناسبًا لمستوى الطالب لهذه الفقرة، باللغة العربية الفصحى المبسطة، في فقرتين إلى ثلاث فقرات. اكتب الملخص فقط بدون أي مقدمة أو تعليق.'
    );
  }

  if (action === 'questions') {
    // A random number is mixed into the prompt so that generating
    // questions again for the exact same text produces a DIFFERENT set
    // of questions each time, instead of the model repeating itself.
    // Note: this action is intentionally never cached — see the
    // /api/generate route for why.
    const varietySeed = Math.floor(Math.random() * 1_000_000);
    return (
      context +
      `اكتب بالضبط ١٠ أسئلة اختيار من متعدد (٤ اختيارات لكل سؤال) لاختبار فهم الطالب لهذه الفقرة، باللغة العربية.
مهم: نوّع صياغة الأسئلة وزاويتها (تعريف، سبب، نتيجة، مقارنة، تطبيق) في كل مرة. (رقم تنويع داخلي: ${varietySeed})
أرجع الإجابة بصيغة JSON فقط بدون أي نص إضافي وبدون markdown، بالشكل التالي بالضبط:
{"questions":[{"question":"نص السؤال","options":["أ","ب","ج","د"],"correctIndex":0}]}
correctIndex هو رقم الاختيار الصحيح (يبدأ من صفر).`
    );
  }

  // flashcards
  const varietySeed = Math.floor(Math.random() * 1_000_000);
  return (
    context +
    `اكتب مجموعة فلاش كاردز (بين ٦ و١٢ كارت حسب محتوى الفقرة) لمراجعة أهم المصطلحات والأفكار في هذه الفقرة، باللغة العربية.
مهم: نوّع اختيار المصطلحات وصياغة الشرح في كل مرة. (رقم تنويع داخلي: ${varietySeed})
أرجع الإجابة بصيغة JSON فقط بدون أي نص إضافي وبدون markdown، بالشكل التالي بالضبط:
{"flashcards":[{"front":"المصطلح أو السؤال","back":"الشرح أو الإجابة"}]}`
  );
}

export const OCR_PROMPT = `مهمتك الوحيدة: انسخ النص العربي المكتوب في هذه الصورة حرفيًا كما هو.
قواعد صارمة:
- لا تكتب أي مقدمة مثل "هذا نص الصورة" أو أي تعليق.
- لا تصف الصورة ولا تحلل محتواها.
- لا تستخدم markdown أو علامات اقتباس.
- إذا كانت الصورة غير واضحة تمامًا ولا يمكن قراءة أي نص منها، اكتب فقط الكلمة: تعذر
- غير ذلك، أرجع النص المكتوب فقط وبس، سطرًا بسطر كما يظهر في الصورة.`;
