// Handles the "10 generations per day" rule.
//
// Assumption baked in here (flagged in the spec): the ADMIN_EMAIL user
// is exempt from the daily limit entirely, so you can test the app
// without waiting for a reset or editing the database by hand.

import { createAdminClient } from './supabase/server';

const DAILY_LIMIT = 10;

export async function checkAndIncrementUsage(
  userId: string,
  userEmail: string | undefined
): Promise<{ allowed: boolean; remaining: number }> {
  // Your own account never gets rate-limited.
  if (userEmail && process.env.ADMIN_EMAIL && userEmail === process.env.ADMIN_EMAIL) {
    return { allowed: true, remaining: DAILY_LIMIT };
  }

  const admin = createAdminClient();
  const today = new Date().toISOString().slice(0, 10); // YYYY-MM-DD

  const { data: existing } = await admin
    .from('usage_counters')
    .select('count')
    .eq('user_id', userId)
    .eq('usage_date', today)
    .maybeSingle();

  const currentCount = existing?.count ?? 0;

  if (currentCount >= DAILY_LIMIT) {
    return { allowed: false, remaining: 0 };
  }

  // Upsert: create today's row if it doesn't exist yet, otherwise bump it.
  await admin
    .from('usage_counters')
    .upsert(
      { user_id: userId, usage_date: today, count: currentCount + 1 },
      { onConflict: 'user_id,usage_date' }
    );

  return { allowed: true, remaining: DAILY_LIMIT - (currentCount + 1) };
}
