// Turns (lesson text + subject + grade + action) into a single short
// string. If a student pastes the exact same lesson and picks the same
// options as someone else did before, this produces the same hash —
// which lets us return the cached result instead of calling Gemini
// again and paying for it twice.

import { createHash } from 'crypto';

export function makeCacheKey(params: {
  text: string;
  subject: string;
  grade: string;
  action: string;
}): string {
  const raw = `${params.text}|${params.subject}|${params.grade}|${params.action}`;
  return createHash('sha256').update(raw).digest('hex');
}
