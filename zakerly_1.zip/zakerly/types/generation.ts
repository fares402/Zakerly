export type Subject = 'arabic' | 'english' | 'math' | 'science' | 'social_studies';

export type Grade =
  | 'primary1' | 'primary2' | 'primary3' | 'primary4' | 'primary5' | 'primary6'
  | 'prep1' | 'prep2' | 'prep3'
  | 'secondary1' | 'secondary2' | 'secondary3';

export type Action = 'summary' | 'questions' | 'flashcards';

export interface GenerateRequestBody {
  text: string;
  subject: Subject;
  grade: Grade;
  action: Action;
}

export interface QuestionItem {
  question: string;
  options: string[]; // always length 4
  correctIndex: number; // 0-based
}

export interface FlashcardItem {
  front: string;
  back: string;
}

export type GenerateResult =
  | { summary: string }
  | { questions: QuestionItem[] }
  | { flashcards: FlashcardItem[] };

export interface GenerateSuccessResponse {
  result: GenerateResult;
  cached: boolean;
}

export interface GenerateErrorResponse {
  error: 'rate_limit' | 'invalid_input' | 'gemini_unavailable' | 'unauthorized';
  message: string;
}
