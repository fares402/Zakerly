# ذاكرلي (Zakerly)

مساعد مذاكرة بالذكاء الاصطناعي للطلاب المصريين — Next.js + Supabase + Gemini.

## التشغيل على جهازك (Local)

1. ثبّت الباكدجات:
   ```
   npm install
   ```

2. اعمل نسخة من `.env.example` باسم `.env.local` واملأ القيم:
   - `NEXT_PUBLIC_SUPABASE_URL` و `NEXT_PUBLIC_SUPABASE_ANON_KEY` و `SUPABASE_SERVICE_ROLE_KEY`: من مشروع Supabase بتاعك (Settings > API).
   - `GEMINI_API_KEY`: من https://aistudio.google.com (مجاني).
   - `ADMIN_EMAIL`: إيميلك اللي هتسجل بيه دخول، عشان يبقى ليك محاولات غير محدودة وتقدر تدخل `/admin`.

3. في Supabase، افتح SQL Editor وشغّل محتوى ملف `supabase/schema.sql` مرة واحدة.

4. في Supabase Authentication settings، فعّل Google كـ OAuth provider (لو عايز تسجيل الدخول بجوجل يشتغل).

5. شغّل السيرفر المحلي:
   ```
   npm run dev
   ```
   افتح http://localhost:3000

## النشر على Vercel

1. ارفع الكود على GitHub (ريبو Private لو حابب).
2. ادخل على vercel.com، اعمل تسجيل دخول بحساب GitHub.
3. "Add New Project" واختار الريبو.
4. في خطوة الإعدادات، ضيف نفس المتغيرات اللي في `.env.local` (Environment Variables).
5. دوس Deploy — هتاخد لينك شغال بعد دقيقة أو اتنين، زي `zakerly.vercel.app`.

## هيكل المشروع

راجع القسم الخاص بالـ Folder Structure في الـ spec، أو افتح `app/` و `lib/` و `components/` مباشرة — كل ملف فيه تعليقات بتشرح وظيفته.

## صفحة الإدارة

بعد ما تسجل دخول بالإيميل اللي حطيته في `ADMIN_EMAIL`، افتح `/admin` لتشوف كل المستخدمين المسجلين ومحاولاتهم اليومية.
