// Handles the "take a photo of the book instead of typing" feature.
// Receives a base64-encoded image, asks Gemini to transcribe the Arabic
// text in it, and returns the text so the student can review/edit it
// in the textarea before generating anything.
//
// ASSUMPTION: using this does NOT count against the daily 10-generation
// limit — only actually clicking "summary" / "questions" / "flashcards"
// does. A student can photograph several pages while only "spending"
// one generation. Flag if you'd rather count OCR calls too.

import { NextResponse } from 'next/server';
import { createServerClient } from '@/lib/supabase/server';
import { generateFromImage } from '@/lib/gemini';
import { OCR_PROMPT } from '@/lib/prompts';

const MAX_IMAGE_BYTES = 5 * 1024 * 1024; // 5MB, matches typical phone photo after compression

export async function POST(request: Request) {
  const supabase = createServerClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json(
      { error: 'unauthorized', message: 'من فضلك سجّل دخولك الأول.' },
      { status: 401 }
    );
  }

  const body = await request.json();
  const { imageBase64, mimeType } = body as { imageBase64: string; mimeType: string };

  if (!imageBase64 || !mimeType) {
    return NextResponse.json(
      { error: 'invalid_input', message: 'مفيش صورة اتبعتت.' },
      { status: 400 }
    );
  }

  // Rough size check (base64 is ~33% larger than the raw bytes)
  const approxBytes = imageBase64.length * 0.75;
  if (approxBytes > MAX_IMAGE_BYTES) {
    return NextResponse.json(
      { error: 'invalid_input', message: 'الصورة كبيرة جدًا، جرب صورة أصغر.' },
      { status: 400 }
    );
  }

  try {
    const rawText = await generateFromImage(imageBase64, mimeType, OCR_PROMPT);
    const extracted = rawText.trim();

    const looksEmpty = !extracted || extracted === 'تعذر';
    if (looksEmpty) {
      return NextResponse.json(
        { error: 'invalid_input', message: 'مقدرناش نقرأ نص واضح من الصورة دي، جرب صورة أوضح وإضاءة أحسن.' },
        { status: 422 }
      );
    }

    return NextResponse.json({ text: extracted.slice(0, 8000) });
  } catch (err) {
    console.error('OCR failed:', err);
    return NextResponse.json(
      { error: 'gemini_unavailable', message: 'حصل خطأ في قراءة الصورة، حاول تاني.' },
      { status: 503 }
    );
  }
}
